package com.newrelic.instrumentation.labs.sap.channel.monitoring;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import com.newrelic.api.agent.NewRelic;
import com.sap.aii.af.service.administration.api.monitoring.ChannelState;
import com.sap.aii.af.service.administration.api.monitoring.ChannelStatus;
import com.sap.aii.af.service.administration.api.monitoring.ProcessState;
import com.sap.aii.af.service.administration.impl.AdminManagerImpl;
import com.sap.aii.af.service.administration.monitoring.ActivationState;
import com.sap.aii.af.service.administration.monitoring.AutomationState;
import com.sap.aii.af.service.administration.monitoring.ChannelActivationStatus;
import com.sap.aii.af.service.administration.monitoring.ChannelAutomationStatus;
import com.sap.aii.af.service.administration.monitoring.ClusterChannelRuntimeStatus;
import com.sap.aii.af.service.administration.monitoring.ClusterChannelStatusOverview;
import com.sap.aii.af.service.administration.monitoring.ProcessStatus;
import com.sap.aii.af.service.administration.monitoring.ProcessStatusSet;
import com.sap.aii.af.service.cpa.Channel;
import com.sap.aii.mdt.itsam.mbeans.utils.XIAdapterChannelUtil;

public class ChannelMonitor implements Runnable {

	public static boolean initialized = false;
	private static ChannelMonitoringConfig currentChannelConfig = null;
	protected static boolean enabled = true;


	public static void init() {
		if(!initialized) {
			try {

				if(currentChannelConfig == null) {
					currentChannelConfig = ChannelMonitoringLogger.getConfig();
					NewRelic.getAgent().getInsights().recordCustomEvent("ChannelMonitoringConfig", currentChannelConfig.getCurrentSettings());
				}

				enabled = currentChannelConfig.isEnabled();

				ScheduledExecutorService executor = Executors.newScheduledThreadPool(2);
				executor.scheduleAtFixedRate(new ChannelMonitor(), 2L, 2L, TimeUnit.MINUTES);
				initialized = true;
				NewRelic.getAgent().getLogger().log(java.util.logging.Level.FINE, ", log file is {0}",currentChannelConfig.getChannelLog());

			} catch (Exception e) {
				NewRelic.getAgent().getLogger().log(java.util.logging.Level.FINE, e, "Failed to open channel monitoring log");
			}


		}
	}

	@Override
	public void run() {

		NewRelic.recordMetric("SAP/ChannelMonitoring/Collection",1);
		if(!enabled) {
			NewRelic.getAgent().getLogger().log(java.util.logging.Level.FINEST, "Channel Monitoring is disabled, skipping monitoring");
			return;
		}

		if(!initialized) {
			init();
		}

		try {
			AdminManagerImpl adminManager = AdminManagerImpl.getInstance();

			Channel[] allChannels = XIAdapterChannelUtil.getAllChannels();

			HashSet<String> channelNames = new HashSet<>();
			HashMap<String, String> idToChannel = new HashMap<>();

			for(Channel channel : allChannels) {
				channelNames.add(channel.getChannelName());
				idToChannel.put(channel.getObjectId(), channel.getChannelName());
			}

			HashSet<String> stoppedChannels = new HashSet<>();
			HashSet<String> unknownChannels = new HashSet<>();
			HashSet<String> runningChannels = new HashSet<>();


			HashMap<String, ChannelActivationStatus> activationMap = adminManager.getChannelActivationStatusHashMap(allChannels);
			for(String channel : activationMap.keySet()) {
				String name = idToChannel.get(channel);
				ChannelActivationStatus actStatus = activationMap.get(channel);
				if(actStatus != null) {
					ActivationState actState = actStatus.getActivationState();
					if(actState == ActivationState.STOPPED) {
						stoppedChannels.add(name);
					} else if(actState == ActivationState.UNKNOWN) {
						unknownChannels.add(name);
					} else {
						runningChannels.add(name);
					}
				}
			}
			ClusterChannelStatusOverview overview = adminManager.getChannelStatusOverview();
			ChannelMonitoringLogger.logToChannelMonitor("CollectionTimestamp: " + new Date());

			int numberOfNodes = overview.getNodeCount();
			ChannelMonitoringLogger.logToChannelMonitor("Number of Nodes: " + numberOfNodes);

			for(int i=0;i<numberOfNodes;i++) {
				String nodeName = overview.getNodeName(i);
				ChannelMonitoringLogger.logToChannelMonitor("Node: " + nodeName);
				HashSet<String> inactive = overview.getInactiveChannels(i);
				HashSet<String> inactive_Named = new HashSet<>();
				for(String id : inactive) {
					String name = idToChannel.get(id);
					inactive_Named.add(name);
				}
				
				
				HashSet<String> withErrors = overview.getChannelsWithProcessingErrors(i);
				HashSet<String> withErrors_Named = new HashSet<>();
				for(String id : withErrors) {
					String name = idToChannel.get(id);
					withErrors_Named.add(name);
				}
				

				HashSet<String> erronenous = overview.getErroneousChannels(i);
				HashSet<String> erronenous_Named = new HashSet<>();
				for(String id : erronenous) {
					String name = idToChannel.get(id);
					erronenous_Named.add(name);
				}


				HashMap<String, Object> attributes = new HashMap<>();
				attributes.put("NodeName", nodeName);
				attributes.put("Number Of Inactive Channels", inactive.size());
				attributes.put("Number Of Channels With Errors", withErrors.size());
				attributes.put("Number Of Erronous Channels", erronenous.size());
				NewRelic.getAgent().getInsights().recordCustomEvent("ClusterChannelOverview", attributes);
				
				reportClusterNode(nodeName, inactive_Named, erronenous_Named, withErrors_Named, stoppedChannels, runningChannels);

			}


			//			int numChannelStatuses = 0;
			//			int numChannelActivations = 0;
			//			int numChannelAutomations = 0;
			//			int numClusterStatuses = 0;
			//			ChannelMonitoringLogger.logToChannelMonitor("CollectionTimestamp: " + new Date());
			//			
			//			for(Channel channel : allChannels) {
			//				NewRelic.getAgent().getLogger().log(Level.FINE,"ChannelMonitoring - Gathering channel info on {0}", channel.getChannelName());
			//				StringBuffer sb = new StringBuffer();
			//
			//				String channelName = channel.getChannelName();
			//				sb.append("Channel - Name: " + channelName + ",");
			//				ChannelStatus channelStatus = adminManager.getChannelStatus(channel, Locale.getDefault());
			//				report(channelStatus, sb);
			//				sb.append(',');
			//				numChannelStatuses++;
			//
			//				ChannelActivationStatus activationStatus = adminManager.getChannelActivationStatus(channel);
			//				if(activationStatus != null) {
			//					ActivationState actState = activationStatus.getActivationState();
			//					if(actState == ActivationState.STOPPED) {
			//						stoppedChannels.add(channelName);
			//					}
			//				}
			//				report(activationStatus, sb);
			//				
			//				numChannelActivations++;
			//				sb.append(',');
			//
			//				ChannelAutomationStatus automationStatus = adminManager.getChannelAutomationStatus(channel);
			//				report(automationStatus, sb);
			//				sb.append(',');
			//				numChannelAutomations++;
			//
			//				ClusterChannelRuntimeStatus clusterStatus = adminManager.getClusterChannelRuntimeStatus(channel, Locale.getDefault());
			//				report(clusterStatus, sb);
			//				numClusterStatuses++;
			//				NewRelic.getAgent().getLogger().log(Level.FINE,"ChannelMonitoring - Finished gathering channel info on {0}", channel.getChannelName());
			//
			//
			//				ChannelMonitoringLogger.logToChannelMonitor(sb.toString());
			//			}
			//			reportClusterChannelStatusOverview(overview, stoppedChannels);
			//
			//			NewRelic.recordMetric("SAP/ChannelMonitoring/ChannelStatuses",numChannelStatuses);
			//			NewRelic.recordMetric("SAP/ChannelMonitoring/ChannelActivationStatuses",numChannelActivations);
			//			NewRelic.recordMetric("SAP/ChannelMonitoring/ChannelAutomationStatuses",numChannelAutomations);
			//			NewRelic.recordMetric("SAP/ChannelMonitoring/ClusterChannelRuntimeStatus",numClusterStatuses);


		} catch(Exception e) {
			NewRelic.getAgent().getLogger().log(Level.FINE, e, "Error executing Channel Monitoring");
		}

	}

	private static void reportClusterNode(String nodeName, HashSet<String> inactives, HashSet<String> errornous, HashSet<String> withErrors, 
			HashSet<String> stopped, Set<String> running) {
		ChannelMonitoringLogger.logToChannelMonitor("Call using Node: " + nodeName + ", inactives=" + inactives + ", erronous=" + errornous + ", withErrors=" +  withErrors + ", stopped=" + stopped + ", running= "+running);
		StringBuffer sb = new StringBuffer();

		sb.append("Node Name: " + nodeName + ",");

		sb.append("Inactive Channels: [");

		if(inactives != null && !inactives.isEmpty()) {
			int i = 0;
			int size = inactives.size();

			for(String id : inactives) {
				sb.append(id);
				i++;
				if (i < size) {
					sb.append(',');
				} 
			}
		} else {
			sb.append(" None Reported ");
		}
		sb.append("],");

		sb.append("Errornous Channels: [");

		if(errornous != null && !errornous.isEmpty()) {
			int i = 0;
			int size = errornous.size();

			for(String id : errornous) {
				sb.append(id);
				i++;
				if(i < size) {
					sb.append(',');
				}
			}
		} else {
			sb.append(" None Reported ");
		}
		sb.append("],");

		sb.append("With Errors Channels: [");

		if(withErrors != null && !withErrors.isEmpty()) {
			int i = 0;
			int size = withErrors.size();

			for(String id : withErrors) {
				sb.append(id);
				i++;
				if(i < size) {
					sb.append(',');
				}
			}
		} else {
			sb.append(" None Reported ");
		}
		sb.append("],");

		sb.append("Stopped Channels: [");

		if(stopped != null && !stopped.isEmpty()) {
			int i = 0;
			int size = stopped.size();

			for(String id : stopped) {
				sb.append(id);
				i++;
				if(i < size) {
					sb.append(',');
				}
			}
		} else {
			sb.append(" None Reported ");
		}
		sb.append("],");

		sb.append("Active Channels: [");

		if(running != null && !running.isEmpty()) {
			int i = 0;
			int size = running.size();

			for(String id : running) {
				sb.append(id);
				i++;
				if(i < size) {
					sb.append(',');
				}
			}
		} else {
			sb.append(" None Reported ");
		}
		sb.append("]");
		
		ChannelMonitoringLogger.logToChannelMonitor(sb.toString());
	}

	private static void reportClusterChannelStatusOverview(ClusterChannelStatusOverview overview, HashSet<String> stopped) {
		if(overview != null) {
			ChannelMonitoringLogger.logToStateLog("CollectionTimestamp: " + new Date());
			int numberOfNodes = overview.getNodeCount();
			for(int i=0;i<numberOfNodes;i++) {
				StringBuffer sb = new StringBuffer();
				String nodeName = overview.getNodeName(i);
				sb.append("Node: ");
				if(nodeName != null) {
					sb.append(nodeName);
				} else {
					sb.append("Unknown Node");
				}
				sb.append(',');
				HashSet<String> inactive = overview.getInactiveChannels(i);
				sb.append("Inactive Channels: [");
				if(inactive != null) {
					if(!inactive.isEmpty()) {
						int size = inactive.size();
						int k = 0;
						for(String channelName : inactive) {
							sb.append(channelName);
							k++;
							if(k < size) {
								sb.append(',');
							}
						}
					} else {
						sb.append(" None Reported ");
					}
				} else {
					sb.append(" None Reported ");
				}
				sb.append("],");
				HashSet<String> withErrors = overview.getChannelsWithProcessingErrors(i);
				sb.append("Channels With Errors: [");
				if(withErrors != null) {
					if(!withErrors.isEmpty()) {
						int size = withErrors.size();
						int k = 0;
						for(String channelName : withErrors) {
							sb.append(channelName);
							k++;
							if(k < size) {
								sb.append(',');
							}
						}
					} else {
						sb.append(" None Reported ");
					}
				} else {
					sb.append(" None Reported ");
				}
				sb.append("],");

				HashSet<String> erronenous = overview.getErroneousChannels(i);
				sb.append("Erronenous Channels: [");
				if(erronenous != null) {
					if(!erronenous.isEmpty()) {
						int size = erronenous.size();
						int k = 0;
						for(String channelName : erronenous) {
							sb.append(channelName);
							k++;
							if(k < size) {
								sb.append(',');
							}
						}
					} else {
						sb.append(" None Reported ");
					}
				} else {
					sb.append(" None Reported ");
				}
				sb.append("],");


			}
		}
	}

	private static void report(ClusterChannelRuntimeStatus status, StringBuffer sb) {
		sb.append("ClusterChannelRuntimeStatus: { ");
		if(status != null) {

			ChannelState state = status.getChannelState();
			sb.append("ChannelState: ");
			if(state != null) {
				sb.append(state);
			} else {
				sb.append("None Reported");
			}
			sb.append(',');
			String msg = status.getMessage();
			sb.append("ChannelMessage: ");
			if(msg != null) {
				sb.append(msg);
			} else {
				sb.append("None Reported");
			}
			sb.append(',');
			ProcessState processState = status.getProcessState();
			sb.append("ProcessState: ");
			if(processState != null) {
				sb.append(processState);
			} else {
				sb.append("None Reported");
			}
			sb.append(',');
			sb.append("ProcessStatusErrorCount: " + status.getProcessStatusErrorCount()+',');
			int nodeCount = status.getNodeCount();
			sb.append("NodeCount: " + nodeCount + ',');
			if(nodeCount > 0) {
				sb.append("Nodes: [");
				for(int i=0;i<nodeCount;i++) {
					sb.append("{");
					String nodeName = status.getNodeName(i);
					sb.append("Node: " + nodeName + ",");

					ChannelStatus nodeStatus = status.getNodeChannelStatus(i);
					sb.append("NodeChannelStatus: ");
					if(nodeStatus != null) {
						sb.append(nodeStatus);
					} else {
						sb.append("None Reported");
					}
					sb.append(',');

					ProcessStatusSet processStatus = status.getNodeProcessStatus(i);
					processState = processStatus.getState();
					sb.append("ProcessState: ");
					if(processState != null) {
						sb.append(processState);
					} else {
						sb.append("None Reported");
					}
					sb.append(',');
					int count = processStatus.size();
					sb.append("ProcessStatus Count: " + count + ',');
					sb.append("ProcessStatuses: [");
					if(count > 0) {
						for(int j=0;j<count;j++) {
							ProcessStatus pStatus = processStatus.getProcessStatus(j);
							if(pStatus != null) {
								sb.append(j);
								sb.append(": ");
								sb.append(pStatus);
								if(j < count-1) {
									sb.append(',');
								}

							}
						}
					} else {
						sb.append(" None Reported ");
					}
					sb.append(']');
					sb.append('}');
					if(i < nodeCount - 1) {
						sb.append(',');
					}
				}
				sb.append(']');
			} else {
				sb.append("Nodes: [ None Reported ]");
			}
			sb.append('}');
		} else {
			sb.append("None Reported }");
		}
	}

	private static void report(ChannelAutomationStatus status, StringBuffer sb) {
		sb.append("AutomationState: { ");
		if(status != null) {
			AutomationState autoState = status.getState();
			Date lastMod = status.getLastModificationTime();
			sb.append("AutomationState: ");
			sb.append(autoState);
			sb.append(',');
			sb.append("Last Modication: ");
			sb.append(lastMod);
			sb.append('}');
		} else {
			sb.append("None Reported }");
		}
	}

	private static void report(ChannelActivationStatus status, StringBuffer sb) {
		sb.append("ActivationStatus: {");
		if(status != null) {
			ActivationState actState = status.getActivationState();
			Date lastMod = status.getLastModificationTime();
			sb.append("ActivationState: ");
			sb.append(actState);
			sb.append(',');
			sb.append("Last Modication: ");
			sb.append(lastMod);		
			sb.append('}');
		} else {
			sb.append("None Reported }");
		}
	}

	private static void report(ChannelStatus status, StringBuffer sb) {
		sb.append("ChannelStatus: { ");
		if(status != null) {

			ChannelState state = status.getState();
			if(state != null) {
				sb.append("Channel State: " + state + ",");
			}
			String msg = status.getMessage();
			if(msg != null) {
				sb.append("Channel Message: " + msg);
			}
			sb.append('}');
		} else {
			sb.append("None Reported }");
		}
	}

}
