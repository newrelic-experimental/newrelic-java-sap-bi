package com.newrelic.instrumentation.labs.sap.channel.monitoring;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import com.newrelic.agent.deps.org.json.simple.JSONArray;
import com.newrelic.agent.deps.org.json.simple.JSONObject;
import com.newrelic.api.agent.NewRelic;
import com.sap.aii.af.service.administration.api.monitoring.ChannelState;
import com.sap.aii.af.service.administration.api.monitoring.ChannelStatus;
import com.sap.aii.af.service.administration.api.monitoring.ProcessState;
import com.sap.aii.af.service.administration.impl.AdminManagerImpl;
import com.sap.aii.af.service.administration.monitoring.ActivationState;
import com.sap.aii.af.service.administration.monitoring.AutomationState;
import com.sap.aii.af.service.administration.monitoring.ChannelActivationStatus;
import com.sap.aii.af.service.administration.monitoring.ChannelAutomationStatus;
import com.sap.aii.af.service.administration.monitoring.ClusterChannelRuntimeStatus;
import com.sap.aii.af.service.administration.monitoring.ClusterChannelStatusOverview;
import com.sap.aii.af.service.administration.monitoring.ProcessStatus;
import com.sap.aii.af.service.administration.monitoring.ProcessStatusSet;
import com.sap.aii.af.service.cpa.Channel;
import com.sap.aii.mdt.itsam.mbeans.utils.XIAdapterChannelUtil;

public class ChannelMonitor implements Runnable {

	public static boolean initialized = false;
	private static ChannelMonitoringConfig currentChannelConfig = null;
	protected static boolean enabled = true;
	protected static enum REPORTING {JSON, CSV}
	protected static REPORTING reportingType = REPORTING.CSV;
	

	public static void init() {
		if(!initialized) {
			try {

				if(currentChannelConfig == null) {
					currentChannelConfig = ChannelMonitoringLogger.getConfig();
					NewRelic.getAgent().getInsights().recordCustomEvent("ChannelMonitoringConfig", currentChannelConfig.getCurrentSettings());
				}

				enabled = currentChannelConfig.isEnabled();
				reportingType = currentChannelConfig.getReportingType();

				ScheduledExecutorService executor = Executors.newScheduledThreadPool(2);
				executor.scheduleAtFixedRate(new ChannelMonitor(), 2L, 2L, TimeUnit.MINUTES);
				initialized = true;
				NewRelic.getAgent().getLogger().log(java.util.logging.Level.FINE, ", log file is {0}",currentChannelConfig.getChannelLog());

			} catch (Exception e) {
				NewRelic.getAgent().getLogger().log(java.util.logging.Level.FINE, e, "Failed to open channel monitoring log");
			}


		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public void run() {

		NewRelic.recordMetric("SAP/ChannelMonitoring/Collection",1);
		if(!enabled) {
			NewRelic.getAgent().getLogger().log(java.util.logging.Level.FINEST, "Channel Monitoring is disabled, skipping monitoring");
			return;
		}

		if(!initialized) {
			init();
		}

		try {
			AdminManagerImpl adminManager = AdminManagerImpl.getInstance();

			Channel[] allChannels = XIAdapterChannelUtil.getAllChannels();

			ClusterChannelStatusOverview overview = adminManager.getChannelStatusOverview();

			int numberOfNodes = overview.getNodeCount();

			for(int i=0;i<numberOfNodes;i++) {
				String nodeName = overview.getNodeName(i);
				HashSet<String> inactive = overview.getInactiveChannels(i);
				HashSet<String> withErrors = overview.getChannelsWithProcessingErrors(i);
				HashSet<String> erronenous = overview.getErroneousChannels(i);
				HashMap<String, Object> attributes = new HashMap<>();
				attributes.put("NodeName", nodeName);
				attributes.put("Number Of Inactive Channels", inactive.size());
				attributes.put("Number Of Channels With Errors", withErrors.size());
				attributes.put("Number Of Erronous Channels", erronenous.size());
				NewRelic.getAgent().getInsights().recordCustomEvent("ClusterChannelOverview", attributes);
			}


			int numChannelStatuses = 0;
			int numChannelActivations = 0;
			int numChannelAutomations = 0;
			int numClusterStatuses = 0;
			boolean isCSV = reportingType == REPORTING.CSV;
			
			
			for(Channel channel : allChannels) {
				NewRelic.getAgent().getLogger().log(Level.FINE,"ChannelMonitoring - Gathering channel info on {0}", channel.getChannelName());
				StringBuffer sb = new StringBuffer();
				JSONObject channelJsonObj = new JSONObject();
				
				if(isCSV) {
					sb.append("Channel - Name: " + channel.getChannelName());
				} else {
					channelJsonObj.put("ChannelName", channel.getChannelName());
				}
				ChannelStatus channelStatus = adminManager.getChannelStatus(channel, Locale.getDefault());
				if(channelStatus != null) {
					if(isCSV) {
						report(channelStatus, sb);
					} else {
						JSONObject channelStatusObj = report(channelStatus);
						channelJsonObj.put("ChannelStatus", channelStatusObj);
					}
					numChannelStatuses++;
				}

				ChannelActivationStatus activationStatus = adminManager.getChannelActivationStatus(channel);
				if(activationStatus != null) {
					if(isCSV) {
						report(activationStatus, sb);
					} else {
						JSONObject actJsonObj = reportJSON(activationStatus);
						channelJsonObj.put("ActivationStatus", actJsonObj);
					}
					numChannelActivations++;
				}

				ChannelAutomationStatus automationStatus = adminManager.getChannelAutomationStatus(channel);
				if(automationStatus != null) {
					if(isCSV) {
						report(automationStatus, sb);
					} else {
						JSONObject automationObj = reportJSON(automationStatus);
						channelJsonObj.put("AutomationStatus", automationObj);
					}
					numChannelAutomations++;
				}

				ClusterChannelRuntimeStatus clusterStatus = adminManager.getClusterChannelRuntimeStatus(channel, Locale.getDefault());
				if(clusterStatus != null) {
					if(isCSV) {
						report(clusterStatus, sb);
					} else {
						JSONObject clusterObj = reportJSON(clusterStatus);
						channelJsonObj.put("ClusterRuntimeStatus", clusterObj);
					}
					numClusterStatuses++;
				}
				NewRelic.getAgent().getLogger().log(Level.FINE,"ChannelMonitoring - Finished gathering channel info on {0}", channel.getChannelName());

				
				if(isCSV) {
					ChannelMonitoringLogger.log(sb.toString());
				} else {
					NewRelic.getAgent().getLogger().log(Level.FINE,"ChannelMonitoring - Writing Channel {0} JSON to log: {1}", channel.getChannelName(),channelJsonObj.toJSONString());
					ChannelMonitoringLogger.log(channelJsonObj.toJSONString());
					NewRelic.getAgent().getLogger().log(Level.FINE,"ChannelMonitoring - Wrote Channel {0} JSON to log", channel.getChannelName());
				}
			}

			NewRelic.recordMetric("SAP/ChannelMonitoring/ChannelStatuses",numChannelStatuses);
			NewRelic.recordMetric("SAP/ChannelMonitoring/ChannelActivationStatuses",numChannelActivations);
			NewRelic.recordMetric("SAP/ChannelMonitoring/ChannelAutomationStatuses",numChannelAutomations);
			NewRelic.recordMetric("SAP/ChannelMonitoring/ClusterChannelRuntimeStatus",numClusterStatuses);


		} catch(Exception e) {
			NewRelic.getAgent().getLogger().log(Level.FINE, e, "Error executing Channel Monitoring");
		}

	}

	private static void report(ClusterChannelRuntimeStatus status, StringBuffer sb) {
		if(status != null) {
			sb.append("ClusterChannelRuntimeStatus: { ");

			ChannelState state = status.getChannelState();
			if(state != null) {
				sb.append("ChannelState: ");
				sb.append(state);
				sb.append(',');
			}
			String msg = status.getMessage();
			if(msg != null) {
				sb.append("ChannelMessage: ");
				sb.append(msg);
				sb.append(',');
			}
			ProcessState processState = status.getProcessState();
			if(processState != null) {
				sb.append("ProcessState: ");
				sb.append(processState);
				sb.append(',');
			}
			sb.append("ProcessStatusErrorCount: " + status.getProcessStatusErrorCount()+',');
			int nodeCount = status.getNodeCount();
			if(nodeCount > 0) {
				sb.append("Nodes: [");
				for(int i=0;i<nodeCount;i++) {
					sb.append("{");
					String nodeName = status.getNodeName(i);
					sb.append("Node: " + nodeName + ",");

					ChannelStatus nodeStatus = status.getNodeChannelStatus(i);
					if(nodeStatus != null) {
						sb.append("NodeChannelStatus: ");
						sb.append(nodeStatus);
						sb.append(',');
					}

					ProcessStatusSet processStatus = status.getNodeProcessStatus(i);
					processState = processStatus.getState();
					if(processState != null) {
						sb.append("ProcessState: ");
						sb.append(processState);
						sb.append(',');
					}
					int count = processStatus.size();
					if(count > 0) {
						sb.append("ProcessStatuses: [");
						for(int j=0;j<count;j++) {
							ProcessStatus pStatus = processStatus.getProcessStatus(j);
							if(pStatus != null) {
								sb.append(j);
								sb.append(": ");
								sb.append(pStatus);
								sb.append(',');

							}
						}
						sb.append(']');
					}
				}
				sb.append(']');
			}
		}
	}

	@SuppressWarnings("unchecked")
	private static JSONObject reportJSON(ClusterChannelRuntimeStatus status) {
		JSONObject json = null;

		if(status != null) {
			json = new JSONObject();

			ChannelState state = status.getChannelState();
			if(state != null) {
				json.put("ChannelState", state);
			}
			String msg = status.getMessage();
			if(msg != null) {
				json.put("ChannelMessage", msg);
			}
			ProcessState processState = status.getProcessState();
			if(processState != null) {
				json.put("ProcessState",processState);
			}
			json.put("ProcessStatusErrorCount", status.getProcessStatusErrorCount());
			int nodeCount = status.getNodeCount();
			if(nodeCount > 0) {
				JSONArray jsonArray = new JSONArray();

				for(int i=0;i<nodeCount;i++) {
					JSONObject nodeObj = new JSONObject();

					String nodeName = status.getNodeName(i);
					nodeObj.put("NodeName", nodeName);

					ChannelStatus nodeStatus = status.getNodeChannelStatus(i);
					if(nodeStatus != null) {
						nodeObj.put("NodeChannelStatus",nodeStatus);
					}

					ProcessStatusSet processStatus = status.getNodeProcessStatus(i);
					processState = processStatus.getState();
					JSONObject processJson = new JSONObject();

					if(processState != null) {
						processJson.put("ProcessState",processState);
					}
					int count = processStatus.size();
					if(count > 0) {
						JSONArray processArray = new JSONArray();

						for(int j=0;j<count;j++) {
							ProcessStatus pStatus = processStatus.getProcessStatus(j);
							JSONObject pJson = new JSONObject();
							pJson.put("ProcessStatus"+j, pStatus);
							processArray.add(processJson);
						}
						processJson.put("ProcessStatuses",processArray);

					}
					nodeObj.put("ProcessStatus",processJson);
					jsonArray.add(processJson);
				}
				json.put("NodeProcesses", jsonArray);
			}
		}
		return json;
	}

	private static void report(ChannelAutomationStatus status, StringBuffer sb) {
		if(status != null) {
			AutomationState autoState = status.getState();
			Date lastMod = status.getLastModificationTime();
			sb.append("AutomationState: { ");
			sb.append("AutomationState: ");
			sb.append(autoState);
			sb.append(',');
			sb.append("Last Modication: ");
			sb.append(lastMod);
			sb.append('}');
		}
	}

	@SuppressWarnings("unchecked")
	private static JSONObject reportJSON(ChannelAutomationStatus status) {
		JSONObject json = null;
		if(status != null) {
			json = new JSONObject();
			AutomationState autoState = status.getState();
			Date lastMod = status.getLastModificationTime();
			json.put("AutomationState",autoState);
			json.put("Last Modication",lastMod);

		}
		return json;
	}

	private static void report(ChannelActivationStatus status, StringBuffer sb) {
		if(status != null) {
			ActivationState actState = status.getActivationState();
			Date lastMod = status.getLastModificationTime();
			sb.append("ActivationStatus: {");
			sb.append("ActivationState: ");
			sb.append(actState);
			sb.append(',');
			sb.append("Last Modication: ");
			sb.append(lastMod);		
			sb.append('}');
		}
	}

	@SuppressWarnings("unchecked")
	private static JSONObject reportJSON(ChannelActivationStatus status) {
		JSONObject json = null;
		if(status != null) {
			json = new JSONObject();
			ActivationState actState = status.getActivationState();
			Date lastMod = status.getLastModificationTime();
			json.put("ActivationState",actState);
			json.put("Last Modication",lastMod);			
		}
		return json;
	}

	private static void report(ChannelStatus status, StringBuffer sb) {
		if(status != null) {

			sb.append("ChannelStatus: { ");
			ChannelState state = status.getState();
			if(state != null) {
				sb.append("Channel State: " + state + ",");
			}
			String msg = status.getMessage();
			if(msg != null) {
				sb.append("Channel Message: " + msg);
			}
			sb.append('}');
		}
	}

	@SuppressWarnings("unchecked")
	private static JSONObject report(ChannelStatus status) {
		JSONObject json = null;
		if(status != null) {
			json = new JSONObject();
			
			ChannelState state = status.getState();
			if(state != null) {
				json.put("Channel State",state);
			}
			String msg = status.getMessage();
			if(msg != null) {
				json.put("Channel Message",msg);
			}
		}
		return json;
	}


}
